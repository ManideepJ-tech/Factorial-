package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class FactorialAutomation {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Launching the browser with URL
        driver.get("https://qainterview.pythonanywhere.com/");
        System.out.println("Launching the browser with URL");

        // Maximizing the browser window
        driver.manage().window().maximize();
        Thread.sleep(500);

        // Finding the text box element and entering the value
        driver.findElement(By.xpath("//input[@id='number']")).sendKeys("5");

        System.out.println("Finding Text Box");

        // Performing click action on the Calculate button
        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg']")).click();
        System.out.println("Click Calculate button");
        Thread.sleep(1000);
        //validating the results
        String text = driver.findElement(By.xpath("//p[@id = 'resultDiv']")).getText();
        if(text.equalsIgnoreCase("The factorial of 5 is: 120")){
            System.out.println("The result is validated");
        } else {
            System.out.println("The result is not correct");
        }

        // Clicking on the "About" hyperlink
        driver.findElement(By.xpath("/html/body/div[2]/div/p[1]/a[1]")).click();
        System.out.println("Click on About Link");

        // Redirecting to the Home page
        driver.navigate().to("https://qainterview.pythonanywhere.com");
        System.out.println("Redirected to Home page from Link page");

        // Finding the "Terms and Conditions" hyperlink by using LinkText locator
        driver.findElement(By.linkText("Terms and Conditions")).click();
        System.out.println("Click on Terms and Conditions Link");

        // Redirecting to the Home page again
        driver.navigate().to("https://qainterview.pythonanywhere.com");
        System.out.println("Redirected to Home page from Link page");

        // Finding the "Privacy" hyperlink by using partial LinkText locator
        driver.findElement(By.partialLinkText("Priv")).click();

        System.out.println("Click on Privacy Link");

        // Redirecting to the Home page again
        driver.navigate().to("https://qainterview.pythonanywhere.com");
        System.out.println("Redirected to Home page from Link page");

        // Finding CopyRight element by CSS Selector
        driver.findElement(By.cssSelector("body > div.col-md-12 > div > p:nth-child(2) > a")).click();
        System.out.println("Copy Right Message");

        Thread.sleep(1000);

        // Closing the browser
        driver.quit();
        System.out.println("Browser closed successfully");
        }
    }